var express = require('express');
var http = require('http');
var path = require('path');
const bodyParser = require('body-parser');
var app = express();
const nav=[
{link:"/authors",name:"Authors"},
{link:"/books",name:"Books"},
{link:"/signup",name:"Signup"},{link:"/login",name:"Login"},
{link:"/admin",name:"AddBook"},
{link:"/admin/update",name:"UpdateBook"},
{link:"/admin/delete",name:"DelBook"},
{link:"/admin/author",name:"AddAuth"},
{link:"/admin/author/update",name:"UpdateAuth"},
{link:"/admin/author/delete",name:"DelAuth"}
]
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var indexRouter = require("./src/routes/indexRouter")(nav)
var authorRouter = require('./src/routes/authorRouter')(nav)
var bookRouter = require('./src/routes/bookRouter')(nav)
var loginRouter = require('./src/routes/loginRouter')(nav)
var adminRouter = require('./src/routes/adminRouter')(nav)
var signupRouter = require('./src/routes/signupRouter')
app.set('views', path.join(__dirname, './src/views'));
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));
app.use(express.urlencoded({extended:true}))
app.use('/', indexRouter);
app.use("/authors",authorRouter)
app.use("/books",bookRouter)
app.use('/login', loginRouter);
app.use('/signup', signupRouter);
app.use("/admin",adminRouter)
app.listen(3000);
