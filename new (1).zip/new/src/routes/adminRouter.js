var express = require('express');
const BookData = require('../model/BookData');
const AuthorData = require('../model/AuthorData');
var router = express.Router();
function routers(nav){
    router.get("/",(req,res)=>{
        res.render("addBook",{nav,title:"AddBook"});
    });
    router.post("/",(req,res)=>{
        var item={
            title:req.body.title,
            author:req.body.author,
            genre:req.body.genre,
            image:req.body.image
        }
        var book=BookData(item)
        book.save(item,(err,data)=>{
            if(err)
            {res.render("error has occured")}
            else
            {
                res.redirect('/books')
            }
        })
    });
    router.get("/delete",(req,res)=>{
        res.render("deleteBook",{nav,title:"DeleteBook"});
    });
    router.get("/update",(req,res)=>{
        res.render("updateBook",{nav,title:"UpdateBook"});
    });
    router.post('/update', function(req, res, next) {
        BookData.findOneAndUpdate({title:req.body.title},{author:req.body.author,
            genre:req.body.genre,image:req.body.image}).then((authors)=>{
          console.log("Updated"+authors)
          res.redirect('/books')
        
        })
        });
        router.post('/delete', function(req, res, next) {
            console.log("req.body"+JSON.stringify(req.body))
            BookData.findOneAndDelete({title:req.body.bookName}).then((data)=>{
              
              res.redirect('/books')
            
            })
            });




















            router.get("/author",(req,res)=>{
                res.render("addAuthor",{nav,title:"AddAuthor"});
            });
            router.post("/author",(req,res)=>{
                var item={
                    name:req.body.name,
                    mail:req.body.mail,
                    genre:req.body.genre,
                    image:req.body.image
                }
                var author=AuthorData(item)
                author.save(item,(err,data)=>{
                    if(err)
                    {res.render("error has occured")}
                    else
                    {
                        res.redirect('/authors')
                    }
                })
            });
            router.get("/author/delete",(req,res)=>{
                res.render("deleteAuthor",{nav,title:"DeleteAuthor"});
            });
            router.get("/author/update",(req,res)=>{
                res.render("updateAuthor",{nav,title:"UpdateAuthor"});
            });
            router.post('/author/update', function(req, res, next) {
                AuthorData.findOneAndUpdate({name:req.body.name},{mail:req.body.mail,
                    genre:req.body.genre,
                    image:req.body.image}).then((authors)=>{
                  console.log("Updated"+authors)
                  res.redirect('/authors')
                
                })
                });
                router.post('/author/delete', function(req, res, next) {
                    console.log("req.body"+JSON.stringify(req.body))
                    AuthorData.findOneAndDelete({name:req.body.AuthorName}).then((data)=>{
                      
                      res.redirect('/authors')
                    
                    })
                    });
    return router
}


module.exports = routers;