const { compile } = require('ejs');
var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
   res.render('signup');
});
router.post("/post",function(req,res,next){
console.log(JSON.stringify(req.body))
console.log(req.body)
let regnam =/^([A-Za-z\s]+)$/
let regexp = /^([A-Za-z0-9\.\-]+)@([A-Za-z0-9\-]+)\.([a-z]{2,3})(\.[a-z]{2,3})?$/
let regphn =/^\(?([0-9]{3})\)?[\-. ]?([0-9]{3})[\-. ]?([0-9]{4})$/
// let regpas =/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
let regpas =/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{7,}$/
if((regexp.test(req.body.mail))&&(regphn.test(req.body.ph))&&(regnam.test(req.body.name))&&(regpas.test(req.body.password))){
   res.render('login');
}
else{
   res.send("wrong validation")
}
});
module.exports = router;