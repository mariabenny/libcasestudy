var express = require('express');
var router = express.Router();
const BookData=require('../model/BookData')
function routers(nav){
 /* var authors=[{
    name:"Ernest Hemingway",
    img:"http://api.randomuser.me/portraits/thumb/men/58.jpg"},{
      name:"James Joyce",
    img:"http://api.randomuser.me/portraits/thumb/women/56.jpg"},{
        name:"Franz Kafka",
    img:"http://api.randomuser.me/portraits/thumb/men/29.jpg"}] */
/* GET users listing. */
router.get('/', function(req, res, next) {
BookData.find().then((authors)=>{
  console.log(authors)
  res.render("books",{nav,
  title:"Books",authors});

})
});
router.get('/:id', function(req, res, next) {
  BookData.find().then((authors)=>{
    console.log("author"+authors)
    res.render("book",{nav,title:"Book",author:authors[req.params.id]});
  
  })
  
});
return router
}


module.exports = routers;