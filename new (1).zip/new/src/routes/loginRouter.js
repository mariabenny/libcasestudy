var express = require('express');
var router = express.Router();
function routers(nav){
/* GET users listing. */
router.get('/', function(req, res, next) {
  res.render('login');
});
router.post("/post",function(req,res,next){
  let regnam =/^([A-Za-z\s]+)$/
let regexp = /^([A-Za-z0-9\.\-]+)@([A-Za-z0-9\-]+)\.([a-z]{2,3})(\.[a-z]{2,3})?$/
let regphn =/^\(?([0-9]{3})\)?[\-. ]?([0-9]{3})[\-. ]?([0-9]{4})$/
// let regpas =/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
let regpas =/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{7,}$/
if((regexp.test(req.body.mail))&&(regpas.test(req.body.password))){
  res.render("index",{nav,title:"Index"});
}
else{
   res.send("wrong validation")
}
 
});
return router
}
module.exports = routers;