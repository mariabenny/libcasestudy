var express = require('express');
var router = express.Router();
const AuthorData=require('../model/AuthorData')
function routers(nav){
 /* var authors=[{
    name:"Ernest Hemingway",
    img:"http://api.randomuser.me/portraits/thumb/men/58.jpg"},{
      name:"James Joyce",
    img:"http://api.randomuser.me/portraits/thumb/women/56.jpg"},{
        name:"Franz Kafka",
    img:"http://api.randomuser.me/portraits/thumb/men/29.jpg"}] */
/* GET users listing. */
router.get('/', function(req, res, next) {
AuthorData.find().then((authors)=>{
  console.log(authors)
  res.render("authors",{nav,
  title:"Authors",authors});

})
});
router.get('/:id', function(req, res, next) {
  AuthorData.find().then((authors)=>{
    console.log(authors)
    res.render("author",{nav,title:"Authors",author:authors[req.params.id]});
  
  })
  
});
return router
}


module.exports = routers;