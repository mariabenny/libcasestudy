let mongoose=require("mongoose")
const Schema=mongoose.Schema;
mongoose.connect("mongodb+srv://ashwin:9847744893@cluster0.hovp9.mongodb.net/Cluster0?retryWrites=true&w=majority",{ useNewUrlParser: true,useUnifiedTopology: true });
const AuthorSchema=new Schema({
    name:String,
    mail:String,
    genre:String,
    image:String
});
var AuthorData=mongoose.model("authordata",AuthorSchema)
module.exports=AuthorData;